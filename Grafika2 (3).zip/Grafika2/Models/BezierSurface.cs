﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class BezierSurface
    {
        public Vector3[,] ControlPoints { get; private set; }
        public BezierSurface(List<Vector3> points)
        {
            if(points.Count != 16)
            {
                throw new ArgumentException("Powierzchnię Beziera tworzy 16 punktów");
            }
            var p = new Vector3[4, 4];
            for (var i = 0; i < 16; i++)
            {
                p[i / 4, i % 4] = points[i];
            }
            ControlPoints = p;
        }
    }
}
