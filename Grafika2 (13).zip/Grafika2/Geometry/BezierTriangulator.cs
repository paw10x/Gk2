﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public static class BezierTriangulator
    {
        public static int Index(int i, int j, int n) => i*(n+1)+j;
        public static Mesh Triangulate(BezierSurface surface, int n)
        {
            Mesh m = new Mesh(surface);
            
            for(int i = 0; i <= n; i++)
            {
                for(int j = 0; j <= n; j++)
                {
                    float u = i / (float)n; 
                    float v = j / (float)n;
                    MeshVertex ver = new MeshVertex(surface, u, v);
                    m.AddMVertex(ver);
                }
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    var i1 = Index(i, j,n);
                    var i2 = Index(i + 1, j,n);
                    var i3 = Index(i, j + 1,n);
                    var i4 = Index(i + 1, j + 1,n);
                    Triangle t1 = new Triangle(i1, i2, i4);
                    Triangle t2 = new Triangle(i1, i4, i3);
                    m.AddMTriangle(t1);
                    m.AddMTriangle(t2);

                }
            }

            return m;
        }
    }
}
