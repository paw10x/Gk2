﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class TriangleRasterizer
    {
        SoftwareRenderer Renderer;
        LightingCalculator Calculator;
        LightingSettings Settings;
        public Texture2D? NormalMap { get; set; }
        public bool UseNormalMap { get; set; }

        public Vector3 TransformNormal(Vector3 normalfrommap, Vector3 pu, Vector3 pv, Vector3 geometricNormal)
        {
            var N = Vector3.Normalize(geometricNormal);
            pu *= normalfrommap.X; pv*= normalfrommap.Y; N*= normalfrommap.Z;
            var modifiedNormal = pu + pv + N;
            return Vector3.Normalize(modifiedNormal);
        }

        public (float A, float B, float C) CalculateBaryCentric(RasterVertex a, RasterVertex b, RasterVertex c, float x, float y)
        {
            var D = (b.Y - c.Y) * (a.X - c.X) + (c.X - b.X) * (a.Y - c.Y);
            

            var A = ((b.Y - c.Y) * (x - c.X) + (c.X - b.X) * (y - c.Y)) / D;
            var B = ((c.Y - a.Y) * (x - c.X) + (a.X - c.X) * (y - c.Y)) / D;
            var C = 1 - A - B;
            return (A, B, C);

        }

        public float GetEdgeX(RasterVertex a, RasterVertex b,float y)
        {
            if (a.Y == b.Y)
            {
                return a.X;
            }
            float t = (y- a.Y)/(b.Y - a.Y);
            float x =a.X +t*(b.X-a.X);
            return x;
        }
        public void FillSpan(int y, float x1, float x2, RasterVertex a, RasterVertex b, RasterVertex c,SurfaceMaterial material)
        {
            var left = Math.Min(x1,x2);
            var right = Math.Max(x2,x1);
            int startX = Math.Max((int)MathF.Ceiling(left - 0.5f),0);
            int endX = Math.Min((int)MathF.Ceiling(right - 0.5f),Renderer.Width);
            for (int x = startX; x < endX; x++)
            {
                float D = (b.Y - c.Y) * (a.X - c.X) + (c.X - b.X) * (a.Y - c.Y);
                if (MathF.Abs(D) < 1e-8f) return;
                var (wa, wb, wc) = CalculateBaryCentric(a,b,c,x+0.5f,y+0.5f);
                var z = wa*a.Z + wb*b.Z + wc*c.Z;
                var normal = wa*a.Normal + wb*b.Normal + wc*c.Normal;
                normal = Vector3.Normalize(normal);
                var u = wa * a.U + wb * b.U + wc * c.U;
                var v = wa * a.V + wb * b.V + wc * c.V;
                var pu = wa* a.Pu + wb*b.Pu + wc*c.Pu;
                var pv = wa * a.Pv + wb*b.Pv + wc*c.Pv;
                Vector3 objectcolor;
                Vector3 finalNormal = normal;

                if (UseNormalMap && NormalMap is not null)
                {
                    var NormalFromMap = NormalMap.SampleNormal(u, v);
                    finalNormal = TransformNormal(NormalFromMap,pu,pv,normal);
                }
                if (material.UseTexture == true && material.Texture is not null)
                {
                    objectcolor = material.Texture.Sample(u,v);
                }
                else
                {
                    objectcolor = material.SolidColor;
                }
                var Position = wa* a.position + wb*b.position + wc*c.position;
                var color = Calculator.CalculateColor(Position, finalNormal, objectcolor, Settings);
                Renderer.SetPixelWithDepth(x, y, z, (byte)MathF.Round(color.X * 255f), (byte)MathF.Round(color.Y * 255f), (byte)MathF.Round(color.Z * 255f));
            }
        }
        public void RasterizeTriangle(RasterVertex a, RasterVertex b, RasterVertex c,SurfaceMaterial material)
        {
            RasterVertex[] vertices = [a, b, c];
            var sortedvertices = vertices.OrderBy(p=>p.Y).ToArray();
            var top = sortedvertices[0];
            var mid = sortedvertices[1];
            var bot = sortedvertices[2];

            if (top.Y != mid.Y)
            {
                var start = (int)Math.Ceiling(top.Y - 0.5);
                var end = (int)Math.Ceiling(mid.Y - 0.5);
                start = Math.Clamp(start, 0, Renderer.Height);
                end = Math.Clamp(end, 0, Renderer.Height);
                for (var y = start; y < end; y++)
                {
                    var SampleY = y + 0.5f;
                    FillSpan(y, GetEdgeX(top, mid, SampleY), GetEdgeX(top, bot, SampleY), a, b, c,material);

                }
            }

            if (mid.Y != bot.Y)
            {
                var start1 = (int)Math.Ceiling(mid.Y - 0.5);
                var end1 = (int)Math.Ceiling(bot.Y - 0.5);
                start1 = Math.Clamp(start1, 0, Renderer.Height);
                end1 = Math.Clamp(end1, 0, Renderer.Height);
                for (var y = start1; y < end1; y++)
                {
                    var SampleY = y + 0.5f;
                    FillSpan(y, GetEdgeX(bot, mid, SampleY), GetEdgeX(top, bot, SampleY), a, b, c, material);

                }
            }
        }
        public TriangleRasterizer(SoftwareRenderer renderer, LightingCalculator calculator, LightingSettings settings)
        {
            Renderer = renderer;
            Calculator= calculator;
            Settings= settings;
        }
    }
}
