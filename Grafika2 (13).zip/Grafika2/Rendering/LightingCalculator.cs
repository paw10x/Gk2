﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Grafika2
{
    public class LightingCalculator
    {
        

        public Vector3 CalculateColor(Vector3 position, Vector3 normal, Vector3 objectColor, LightingSettings settings)
        {
            
            Vector3 N = SafeVectorNormalization.SafeNormalize(normal,Vector3.UnitZ);
            
           
            Vector3 V = new Vector3(0, 0, 1);
            if (Vector3.Dot(N, V) < 0f)
            {
                N = -N;
            }
            Vector3 L = SafeVectorNormalization.SafeNormalize(settings.LightPosition - position,Vector3.Zero);
            if (L == Vector3.Zero)
            {
                return L;
            }
            var kd = settings.Kd;
            var dotNL = Vector3.Dot(N,L);
            var d = MathF.Max(0f,dotNL);
            var Id = kd * Vector3.Multiply(settings.LightColor, objectColor) * d;
            var ks = settings.Ks;

            float s = 0f;

            if (dotNL > 0f)
            {
                var R = 2f * dotNL * N - L;

                var dotVR = Math.Clamp(
                    Vector3.Dot(V, R), 0f, 1f);

                s = MathF.Pow(dotVR, settings.M);
            }
            var Is = ks * Vector3.Multiply(settings.LightColor, objectColor) * s;
            var I = Id + Is;
            I.X = Math.Clamp(I.X, 0f, 1f);
            I.Y = Math.Clamp(I.Y,0f,1f);
            I.Z = Math.Clamp(I.Z, 0f,1f);
            return I;
        }
        
    }
}
