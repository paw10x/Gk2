﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class MeshVertex
    {
        public Vector3 Position { get; set; }
        public Vector3 Pu { get; set; }
        public Vector3 Pv { get; set; }
        public Vector3 Normal { get; set; }
        public float U { get; set; }
        public float V { get; set; }
        public Vector3 RotatedPosition { get; set; }
        public Vector3 RotatedPu { get; set; }
        public Vector3 RotatedNormal { get; set; }
        public Vector3 RotatedPv {  get; set; }

        public MeshVertex(BezierSurface sur, float u,float v)
        {
            
            U = u;
            V = v;
            Position = BezierEvaluator.Evaluate(sur, u, v);
            Pu = BezierEvaluator.EvaluatePu(sur, u, v);
            Pv = BezierEvaluator.EvaluatePv(sur, u, v);
            Normal = BezierEvaluator.EvaluateNormal(sur, u, v);
            RotatedNormal = Vector3.Zero;
            RotatedPu = Vector3.Zero;
            RotatedPv = Vector3.Zero;
            RotatedPosition = Vector3.Zero;
        }
    }
}
