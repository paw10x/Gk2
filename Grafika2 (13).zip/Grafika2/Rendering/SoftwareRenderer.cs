﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Grafika2
{
    public class SoftwareRenderer
    {
        public int Width {  get; set; }
        public int Height { get; set; }
        byte[] pixels;
        WriteableBitmap bitmap;
        public WriteableBitmap getbitmap => bitmap;
        float[] depthBuffer;

        public SoftwareRenderer(int width, int height)
        {
            Width = width;
            Height = height;
            pixels = new byte[Width * Height*4];
            bitmap = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgra32, null);
            depthBuffer = new float[Width * Height];
        }

        public int PixelIndex(int x,int y) => (y*Width + x)*4;
        public void SetPixel(int x, int y, byte r, byte g, byte b)
        {
            if(x<0 ||y<0||x>Width-1 || y > Height - 1)
            {
                return;
            }
            pixels[PixelIndex(x, y)] = b;
            pixels[PixelIndex(x, y)+1] = g;
            pixels[PixelIndex(x, y)+2] = r;
            pixels[PixelIndex(x, y)+3] = 255;
        }
        public void SetPixelWithDepth(int x, int y, float z, byte r, byte g, byte b)
        {
            if (x < 0 || y < 0 || x > Width - 1 || y > Height - 1)
            {
                return;
            }
            if (z > depthBuffer[PixelIndex(x, y) / 4])
            {
                depthBuffer[PixelIndex(x,y) / 4]=z;
                SetPixel(x,y,r,g,b);
            }
        }
        public void Clear()
        {
            for (int x = 0; x < pixels.Length; x++)
            {
                pixels[x] = 255;
            }
            Array.Fill(depthBuffer, float.NegativeInfinity);
        }
        public void Present()
        {
            bitmap.WritePixels(new Int32Rect(0,0,Width,Height),pixels,Width*4,0);
        }
    }
}
