﻿using Grafika2.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2.Services
{
    public class SurfacesFileLoader
    {
        public List<BezierSurface> Load(string path)
        {

            int counter = 0;
            var bezier = new List<BezierSurface>();
            var points = new List<Vector3>();
            foreach (string line in File.ReadLines(path))
            {
                counter++;
                if (string.IsNullOrWhiteSpace(line)) continue;
                string[] koordynaty = line.Split(' ',StringSplitOptions.RemoveEmptyEntries);
                if (koordynaty.Length != 3)
                {
                    throw new FormatException($"Błąd w wierszu {counter}");
                }
                var x = float.Parse(koordynaty[0],CultureInfo.InvariantCulture);
                var y = float.Parse(koordynaty[1],CultureInfo.InvariantCulture);
                var z = float.Parse(koordynaty[2],CultureInfo.InvariantCulture);
                Vector3 point = new Vector3(x, y, z);
                points.Add(point);
                if (points.Count == 16)
                {
                    var sur = new BezierSurface(points);
                    bezier.Add(sur);
                    points.Clear();
                }
            }
            if (points.Count != 0)
            {
                throw new Exception("Niekompletne dane");
            }
            if (bezier.Count < 2)
            {
                throw new Exception("Za mało powierzchni beziera");
            }
            return bezier;
        }

    }
}
