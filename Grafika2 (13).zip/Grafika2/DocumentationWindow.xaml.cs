﻿using System.Windows;

namespace Grafika2
{
    public partial class DocumentationWindow : Window
    {
        public DocumentationWindow()
        {
            InitializeComponent();
        }

        private void CloseButton_Click(
            object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}