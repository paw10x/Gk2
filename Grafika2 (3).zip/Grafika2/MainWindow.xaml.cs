﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Grafika2.Services;
using Grafika2.Models;
using System.Drawing;
using System.Numerics;

namespace Grafika2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Scene scene;
        List<Mesh> meshes;
        double scale = 100;
        public MainWindow()
        {
            InitializeComponent();
            string path = System.IO.Path.Combine(AppContext.BaseDirectory,"Resources", "surfaces.txt");
            var loader = new SurfacesFileLoader();
            var surfaces = loader.Load(path);
            scene = new Scene();
            foreach (var surface in surfaces)
            {
                scene.AddSurface(surface);
            }
            meshes = new();
            foreach (BezierSurface surface in scene.bezierSurfaces)
            {
                Mesh mesh = BezierTriangulator.Triangulate(surface, (int)TriangulationSlider.Value);
                meshes.Add(mesh);
            }
            DrawingCanvas.SizeChanged += DrawingCanvas_SizeChanged;
            Loaded += (sender, e) => RenderScene();

        }
        private void DrawingCanvas_SizeChanged(
    object sender,
    SizeChangedEventArgs e)
        {
            RenderScene();
        }
        
        private void TriangulationSlider_ValueChanged(
    object sender,
    RoutedPropertyChangedEventArgs<double> e)
        {
            if(scene is null)
            {
                return;
            }
            int n = (int)e.NewValue;
            meshes = new();

            foreach (BezierSurface surface in scene.bezierSurfaces)
            {
                Mesh mesh = BezierTriangulator.Triangulate(surface, n);
                meshes.Add(mesh);
            }
            RenderScene();

        }
        private void DrawTline(Vector3 p1, Vector3 p2)
        {
            double scale = 100;

            double x1 = DrawingCanvas.ActualWidth / 2 + p1.X * scale;
            double y1 = DrawingCanvas.ActualHeight / 2 - p1.Y * scale;

            double x2 = DrawingCanvas.ActualWidth / 2 + p2.X * scale;
            double y2 = DrawingCanvas.ActualHeight / 2 - p2.Y * scale;
            Line line = new Line
            {
                X1 = x1,
                Y1 = y1,
                X2 = x2,
                Y2 = y2,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            DrawingCanvas.Children.Add(line);


        }
        void RenderScene()
        {
            DrawingCanvas.Children.Clear();
            foreach (Mesh mesh in meshes)
            {
                foreach (Triangle t in mesh.Triangles)
                {
                    MeshVertex a = mesh.Vertices[t.A];
                    MeshVertex b = mesh.Vertices[t.B];
                    MeshVertex c = mesh.Vertices[t.C];
                    var p1 = a.Position;
                    var p2 = b.Position;
                    var p3 = c.Position;
                    DrawTline(p1, p2);
                    DrawTline(p2, p3);
                    DrawTline(p3, p1);
                }
            }
        }
    }
}