﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public static class SafeVectorNormalization
    {
        public static Vector3 SafeNormalize(Vector3 vector,Vector3 fallback)
        {
            float lengthSquared = vector.LengthSquared();

            if (!float.IsFinite(lengthSquared) ||
                lengthSquared < 1e-12f)
            {
                return fallback;
            }

            return Vector3.Normalize(vector);
        }

    }
}
