﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class Triangle
    {
        public int A { get; }
        public int B { get; }
        public int C { get; }

        public Triangle(int a,int b, int c)
        {
            A = a; B = b; C = c;
        }

    }
}
