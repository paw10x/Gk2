﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Grafika2
{
    public class LightingCalculator
    {
        

        public Vector3 CalculateColor(Vector3 position, Vector3 normal, Vector3 objectColor, LightingSettings settings)
        {
            Vector3 N = Vector3.Normalize(normal);
            
           
            Vector3 V = new Vector3(0, 0, 1);
            if (Vector3.Dot(N, V) < 0f)
            {
                N = -N;
            }
            Vector3 L = Vector3.Normalize(settings.LightPosition - position);
            var komisjadydaktyczna = settings.Kd;
            var d = MathF.Max(0f,Vector3.Dot(N, L));
            var Id = komisjadydaktyczna * Vector3.Multiply(settings.LightColor, objectColor) * d;
            var komisjasocialna = settings.Ks;
            var R = 2 * d * N - L;
            var s = MathF.Pow(MathF.Max(Vector3.Dot(V, R),0f), settings.M);
            var Is = komisjasocialna * Vector3.Multiply(settings.LightColor, objectColor) * s;
            var I = Id + Is;
            I.X = Math.Clamp(I.X, 0f, 1f);
            I.Y = Math.Clamp(I.Y,0f,1f);
            I.Z = Math.Clamp(I.Z, 0f,1f);
            return I;
        }
        
    }
}
