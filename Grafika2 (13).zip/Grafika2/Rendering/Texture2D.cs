﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Numerics;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Grafika2
{
    public class Texture2D
    {
        private readonly byte[] pixels;
        public int Width { get; }
        public int Height { get; }

        public Vector3 Sample(float u, float v)
        {
            u = Math.Clamp(u, 0f, 1f);
            v = Math.Clamp(v, 0f, 1f);
            int x = (int)MathF.Round(u * (Width - 1));
            int y = (int)MathF.Round(v * (Height - 1));
            int index = ((y * Width) + x) * 4;
            return new Vector3(pixels[index+2]/255f, pixels[index+1]/255f, pixels[index]/255f);
        }
        public Vector3 SampleNormal(float u,float v)
        {
            var sampled = Sample(u, v);
            var notnormalized = 2 * sampled - Vector3.One;
            var normalized = SafeVectorNormalization.SafeNormalize(notnormalized,Vector3.UnitZ);
            return normalized;
        }
        public Texture2D(string path)
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(Path.GetFullPath(path),UriKind.Absolute);
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.EndInit();

            Width = bitmap.PixelWidth;
            Height = bitmap.PixelHeight;

            BitmapSource source = bitmap;
            if (source.Format != PixelFormats.Bgra32)
            {
               source = new FormatConvertedBitmap(source, PixelFormats.Bgra32, null, 0);
            }

            pixels = new byte[Width * Height * 4];
            int stride = Width * 4;
            source.CopyPixels(pixels, stride, 0);
        }

    }
}
