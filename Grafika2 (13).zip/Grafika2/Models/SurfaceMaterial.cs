﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class SurfaceMaterial
    {
        public Vector3 SolidColor { get; set; } = Vector3.One;
        public bool UseTexture { get; set; } = false;
        public Texture2D? Texture { get; set; } = null;
    }
}
