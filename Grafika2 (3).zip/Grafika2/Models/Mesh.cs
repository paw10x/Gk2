﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class Mesh
    {
        BezierSurface Surface;
        public List<MeshVertex> Vertices { get; }
        public List<Triangle> Triangles { get; }

        public void AddMVertex(MeshVertex v)
        {
            Vertices.Add(v);
        }
        public void AddMTriangle(Triangle t)
        {
            Triangles.Add(t);
        }
        public Mesh(BezierSurface sur)
        {
            Surface = sur;
            Vertices = new List<MeshVertex>();
            Triangles = new List<Triangle>();

        }
    }
}
