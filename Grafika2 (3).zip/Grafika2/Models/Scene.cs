﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2.Models
{
    public class Scene
    {
        public List<BezierSurface> bezierSurfaces { get; private set; } = new();
        public void AddSurface(BezierSurface s)
        {
            bezierSurfaces.Add(s);
        }
        
    }
}
