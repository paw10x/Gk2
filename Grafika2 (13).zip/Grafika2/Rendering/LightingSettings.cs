﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public class LightingSettings
    {
        public float Kd { get; set; } = 0.7f;
        public float Ks { get; set; } = 0.3f;
        public float M { get; set; } = 20f;
        public Vector3 LightPosition { get; set; } = new Vector3(0, 0, 1);
        public Vector3 LightColor { get; set; } = new Vector3(1, 1, 1);

    }
}
