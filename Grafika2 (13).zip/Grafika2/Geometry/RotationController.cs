﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace Grafika2
{
    public class RotationController
    {
        Matrix4x4 rotation = Matrix4x4.Identity;

        public void Reset()
        {
            rotation = Matrix4x4.Identity;
        }
        public void Rotate(float deltaX, float deltaY)
        {
            float sensitivity = 0.01f;
            var angleY = deltaX * sensitivity;
            var angleX = deltaY * sensitivity;

            Matrix4x4 rx = Matrix4x4.CreateRotationX(angleX);
            Matrix4x4 ry = Matrix4x4.CreateRotationY(angleY);

            var r = rx * ry;
            rotation = rotation * r;
        }
        public Vector3 Transform(Vector3 point)
        {
            return Vector3.Transform(point, rotation);
        }
    }
}
