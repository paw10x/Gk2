﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace Grafika2.Models
{
    public class LightPath
    {
        public List<Vector3> ControlPoints { get; set; }

        public LightPath() { 
        ControlPoints = new List<Vector3>();
            var P0 = new Vector3(-0.7f, 0,1.5f);
            var P1 = new Vector3(-0.7f, 0.9f, 1.5f);
            var P2 = new Vector3(0.7f, 0.9f, 1.5f);
            var P3 = new Vector3(0.7f, 0, 1.5f);
            var P4 = new Vector3(0.7f, -0.9f, 1.5f);
            var P5 = new Vector3(-0.7f, -0.9f, 1.5f);
            var P6 = new Vector3(-0.7f, 0, 1.5f);
            ControlPoints.Add(P0);
            ControlPoints.Add(P1);
            ControlPoints.Add(P2);
            ControlPoints.Add(P3);
            ControlPoints.Add(P4);
            ControlPoints.Add(P5);
            ControlPoints.Add(P6);
        }

        private Vector3 EvaluateSegment(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float s = 1 - t;
            var b0 = s * s * s;
            var b1 = 3 * s * s * t;
            var b2 = 3 * s * t * t;
            var b3 =  t * t * t;
            return b0*p0+ b1 * p1+b2*p2+b3*p3;
        }
        public Vector3 Evaluate(float t)
        {
            t = Math.Clamp(t, 0f, 1f);
            if (t < 0.5f)
            {
                var s = 2 * t;
                return EvaluateSegment(ControlPoints[0], ControlPoints[1], ControlPoints[2], ControlPoints[3], s);
            }
            else
            {
                var s = (t - 0.5f) * 2;
                return EvaluateSegment(ControlPoints[3], ControlPoints[4], ControlPoints[5], ControlPoints[6], s);
            }
        }

    }
}
