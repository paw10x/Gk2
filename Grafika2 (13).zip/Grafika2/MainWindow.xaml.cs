﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Grafika2.Services;
using Grafika2.Models;
using System.Drawing;
using System.Numerics;
using System.Windows.Threading;
using System.Runtime.CompilerServices;
using System.Diagnostics;

namespace Grafika2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Scene scene;
        List<Mesh> meshes;
        List<SurfaceMaterial> Materials;
        double scale = 200;
        RotationController rotationController;
        SoftwareRenderer softwareRenderer;
        TriangleRasterizer rasterizer;
        LightingCalculator lightingCalculator;
        LightingSettings lightingSettings;
        bool isDragging;
        System.Windows.Point lastMousePosition;
        bool updatingMaterialUI = false;
        Texture2D? normalMap;
        bool useNormalMap = false;
        LightPath lightpath;
        DispatcherTimer lightTimer;
        float lightT = 0f;
        float lightSpeed = 0.2f;
        private Stopwatch lightStopwatch = new Stopwatch();
        int selectedLightPoint = -1;
        const double LightPointRadius = 7;
        const double LightPointHitRadius = 12;
        Vector3 sceneCenter = Vector3.Zero;

        Vector3 CalculateSceneCenter()
        {
            Vector3 min = new Vector3(float.PositiveInfinity,float.PositiveInfinity,float.PositiveInfinity);
            Vector3 max = new Vector3(float.NegativeInfinity,float.NegativeInfinity,float.NegativeInfinity);

            foreach (var sur in scene.bezierSurfaces)
            {
                foreach (var point in sur.ControlPoints) { 
                    min = Vector3.Min(min, point);
                    max = Vector3.Max(max, point);
                }
            }
            return (max + min) / 2;
        }
        public void InitializeRenderer()
        {
            softwareRenderer = new SoftwareRenderer((int) Math.Ceiling(DrawingCanvas.ActualWidth), (int)Math.Ceiling(DrawingCanvas.ActualHeight));
            rasterizer = new TriangleRasterizer(softwareRenderer,lightingCalculator,lightingSettings);
            rasterizer.NormalMap = normalMap;
            rasterizer.UseNormalMap = useNormalMap;
            RenderImage.Source = softwareRenderer.getbitmap;
        }
        public MainWindow()
        {
            InitializeComponent();
            string path = System.IO.Path.Combine(AppContext.BaseDirectory,"Resources", "surfaces.txt");
            var loader = new SurfacesFileLoader();
            var surfaces = loader.Load(path);
            rotationController = new();
            scene = new Scene();
            lightingSettings = new LightingSettings();
            lightingCalculator = new LightingCalculator();
            lightpath = new LightPath();
            lightTimer = new DispatcherTimer();
            lightingSettings.LightPosition = lightpath.Evaluate(0f);
            lightTimer.Interval = TimeSpan.FromMilliseconds(16);
            lightTimer.Tick += LightTimer_Tick;
            foreach (var surface in surfaces)
            {
                scene.AddSurface(surface);
            }
            sceneCenter = CalculateSceneCenter();
            Materials = new List<SurfaceMaterial>(surfaces.Count);
            var path1 = System.IO.Path.Combine(AppContext.BaseDirectory, "Resources", "texture.png");
            Texture2D texture2D = new Texture2D(path1);
            int i = 0;
            foreach( var surface in surfaces)
            {
                SurfaceComboBox.Items.Add($"Powierzchnia {i + 1}");
                i++;
            }

            foreach (var surface in scene.bezierSurfaces)
            {
                Materials.Add(new SurfaceMaterial
                {
                    Texture = texture2D,
                    UseTexture = false
                });
            }

            var path2 = System.IO.Path.Combine(AppContext.BaseDirectory, "Resources","normal_4.png");
            normalMap = new Texture2D(path2);
            SurfaceComboBox.SelectedIndex = 0;

            meshes = new();
            foreach (BezierSurface surface in scene.bezierSurfaces)
            {

                Mesh mesh = BezierTriangulator.Triangulate(surface, (int)TriangulationSlider.Value);
                meshes.Add(mesh);
            }
            UpdateRotatedMeshes();
            DrawingCanvas.SizeChanged += DrawingCanvas_SizeChanged;
            Loaded += (sender, e) => { InitializeRenderer(); RenderScene(); };

        }
        RasterVertex ProjectVertex(MeshVertex vertex)
        {
            RasterVertex v = new RasterVertex();
            v.X = (float)(DrawingCanvas.ActualWidth / 2 + vertex.RotatedPosition.X * scale);
            v.Y = (float)(DrawingCanvas.ActualHeight / 2 - vertex.RotatedPosition.Y * scale);
            v.Z = vertex.RotatedPosition.Z;
            v.Normal = vertex.RotatedNormal;
            v.U = vertex.U;
            v.V = vertex.V;
            v.position = vertex.RotatedPosition;
            v.Pu = vertex.RotatedPu;
            v.Pv = vertex.RotatedPv;
            return v;
        }
        

        void UpdateRotatedMeshes()
        {
            foreach (var mesh in meshes) 
            {
                foreach (var vertex in mesh.Vertices) 
                {
                    vertex.RotatedPosition = rotationController.Transform(vertex.Position - sceneCenter);
                    vertex.RotatedPu = rotationController.Transform(vertex.Pu);
                    vertex.RotatedPv = rotationController.Transform(vertex.Pv);
                    vertex.RotatedNormal = SafeVectorNormalization.SafeNormalize(rotationController.Transform(vertex.Normal),Vector3.UnitZ);
                }
            }
        }
        private void DrawingCanvas_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if(scene is null || meshes is null || DrawingCanvas.ActualHeight <= 0 || DrawingCanvas.ActualWidth <= 0)
            {
                return;
            }
            scale = 0.9f* Math.Min(DrawingCanvas.ActualHeight,DrawingCanvas.ActualWidth)/(2*CalculateSceneRadius());
            InitializeRenderer();
            RenderScene();
        }
        
        private void TriangulationSlider_ValueChanged(object sender,RoutedPropertyChangedEventArgs<double> e)
        {
            if(scene is null)
            {
                return;
            }
            int n = (int)e.NewValue;
            meshes = new();

            foreach (BezierSurface surface in scene.bezierSurfaces)
            {
                Mesh mesh = BezierTriangulator.Triangulate(surface, n);
                meshes.Add(mesh);
            }
            UpdateRotatedMeshes();
            RenderScene();

        }
        private void DrawTline(Vector3 p1, Vector3 p2)
        {
            

            double x1 = DrawingCanvas.ActualWidth / 2 + p1.X * scale;
            double y1 = DrawingCanvas.ActualHeight / 2 - p1.Y * scale;

            double x2 = DrawingCanvas.ActualWidth / 2 + p2.X * scale;
            double y2 = DrawingCanvas.ActualHeight / 2 - p2.Y * scale;
            Line line = new Line
            {
                X1 = x1,
                Y1 = y1,
                X2 = x2,
                Y2 = y2,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            DrawingCanvas.Children.Add(line);


        }
        void DrawTriangleMesh()
        {
            foreach(Mesh mesh in meshes)
            {
                foreach(Triangle t in mesh.Triangles)
                {
                    MeshVertex a = mesh.Vertices[t.A];
                    MeshVertex b = mesh.Vertices[t.B];
                    MeshVertex c = mesh.Vertices[t.C];
                    DrawTline(a.RotatedPosition, b.RotatedPosition);
                    DrawTline(b.RotatedPosition, c.RotatedPosition);
                    DrawTline(c.RotatedPosition, a.RotatedPosition);
                }
            }
        }
        void DrawControlPolygons()
        {
            foreach (BezierSurface sur in scene.bezierSurfaces)
            {
                for (int i = 0; i <= 3; i++)
                {
                    for (int j = 0; j <= 3; j++)
                    {
                        var p1 = rotationController.Transform(sur.ControlPoints[i, j]-sceneCenter);
                        if (i < 3)
                        {
                            var p2 = rotationController.Transform(sur.ControlPoints[i + 1, j]-sceneCenter);
                            DrawTline(p1, p2);
                        }
                        if (j < 3)
                        {
                            var p3 = rotationController.Transform(sur.ControlPoints[i, j + 1]-sceneCenter);
                            DrawTline(p1, p3);
                        }
                    }
                }
            }
        }
        void RenderScene()
        {
            if (rasterizer is null) return;
            softwareRenderer.Clear();



            for (int m = 0; m<meshes.Count;m++)
            {
               var mesh = meshes[m];
                var material = Materials[m];
                foreach (Triangle t in mesh.Triangles)
                {
                    MeshVertex a = mesh.Vertices[t.A];
                    MeshVertex b = mesh.Vertices[t.B];
                    MeshVertex c = mesh.Vertices[t.C];
                    var p1 = ProjectVertex(a);
                    var p2 = ProjectVertex(b);
                    var p3 = ProjectVertex(c);
                    if(ShowFilledTrianglesCheckBox.IsChecked ==true)
                    rasterizer.RasterizeTriangle(p1, p2, p3,material);
                    
                }
            }
            softwareRenderer.Present();
            RedrawOverlays();
        }
        float CalculateSceneRadius()
        {
            float maxRadiusSquared = 0f;

            foreach (BezierSurface sur in scene.bezierSurfaces)
            {
                foreach (Vector3 point in sur.ControlPoints)
                {
                    float distanceSquared = (point - sceneCenter).LengthSquared();

                    maxRadiusSquared = MathF.Max(maxRadiusSquared, distanceSquared);
                }
            }

            return MathF.Max(MathF.Sqrt(maxRadiusSquared), 1e-6f);
        }

        private System.Windows.Point LightWorldToScreen(Vector3 position)
        {
            double screenX = DrawingCanvas.ActualWidth / 2 + position.X * scale;

            double screenY = DrawingCanvas.ActualHeight / 2 - position.Y * scale;

            return new System.Windows.Point(screenX, screenY);
        }
        private Vector3 LightScreenToWorld(System.Windows.Point mouse,float z)
        {
            float worldX = (float)((mouse.X - DrawingCanvas.ActualWidth / 2) / scale);

            float worldY = (float)((DrawingCanvas.ActualHeight / 2 - mouse.Y) / scale);

            return new Vector3(worldX, worldY, z);
        }
        private void DrawLightPath()
        {


            if (lightpath is null || lightpath.ControlPoints.Count != 7)
                return;

            // Wielokąt kontrolny
            var controlPolygon = new Polyline
            {
                Stroke = Brushes.Gray,
                StrokeThickness = 1,
                StrokeDashArray = new DoubleCollection { 4, 4 }
            };

            foreach (var point in lightpath.ControlPoints)
            {
                controlPolygon.Points.Add(LightWorldToScreen(point));
            }

            DrawingCanvas.Children.Add(controlPolygon);

            // Zamknięta krzywa Béziera
            var curve = new Polyline
            {
                Stroke = Brushes.Orange,
                StrokeThickness = 2.5
            };

            const int samples = 100;

            for (int i = 0; i <= samples; i++)
            {
                float t = (float)i / samples;
                Vector3 position = lightpath.Evaluate(t);

                curve.Points.Add(LightWorldToScreen(position));
            }

            DrawingCanvas.Children.Add(curve);

            // Punkty kontrolne P0–P5
            for (int i = 0; i < 6; i++)
            {
                var screenPoint = LightWorldToScreen(
                    lightpath.ControlPoints[i]
                );

                var ellipse = new Ellipse
                {
                    Width = LightPointRadius * 2,
                    Height = LightPointRadius * 2,
                    Fill = i == selectedLightPoint ? Brushes.LimeGreen : Brushes.Gold,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                };

                Canvas.SetLeft(ellipse, screenPoint.X - LightPointRadius);
                Canvas.SetTop(ellipse, screenPoint.Y - LightPointRadius);

                DrawingCanvas.Children.Add(ellipse);
            }

            // Aktualna pozycja światła
            var lightPosition = LightWorldToScreen(
                lightpath.Evaluate(lightT)
            );

            var lightMarker = new Ellipse
            {
                Width = 10,
                Height = 10,
                Fill = Brushes.Red,
                Stroke = Brushes.DarkRed,
                StrokeThickness = 1
            };

            Canvas.SetLeft(lightMarker, lightPosition.X - 5);
            Canvas.SetTop(lightMarker, lightPosition.Y - 5);

            DrawingCanvas.Children.Add(lightMarker);
        }

        private int FindLightPoint(System.Windows.Point mouse)
        {
            if (lightpath is null)
                return -1;

            double radiusSquared = LightPointHitRadius * LightPointHitRadius;

            for (int i = 0; i < 6; i++)
            {
                var point = LightWorldToScreen(lightpath.ControlPoints[i]);

                double dx = mouse.X - point.X;
                double dy = mouse.Y - point.Y;

                if (dx * dx + dy * dy <= radiusSquared)
                {
                    return i;
                }
            }

            return -1;
        }
        private void RedrawOverlays()
        {
            DrawingCanvas.Children.Clear();

            if (ShowControlPolygonsCheckBox.IsChecked == true)
            {
                DrawControlPolygons();
            }

            if (ShowTriangleMeshCheckBox.IsChecked == true)
            {
                DrawTriangleMesh();
            }

            DrawLightPath();
        }

        private void DrawingCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var mouse = e.GetPosition(DrawingCanvas);
            int index = FindLightPoint(mouse);

            if (index>=0)
            {
                selectedLightPoint = index;
                isDragging = false;

                DrawingCanvas.CaptureMouse();
                RedrawOverlays();

                e.Handled = true;
                return;
            }
            selectedLightPoint = -1;
            isDragging = true;
            lastMousePosition = e.GetPosition(DrawingCanvas);
            DrawingCanvas.CaptureMouse();
        }

        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            var mouse = e.GetPosition (DrawingCanvas);

            if (selectedLightPoint >= 0)
            {
                if (e.LeftButton != MouseButtonState.Pressed) return;

                int index = selectedLightPoint;
                Vector3 previous = lightpath.ControlPoints[index];

                Vector3 newPosition = LightScreenToWorld(mouse, previous.Z);
                lightpath.SetControlPoint(index, newPosition);

                lightingSettings.LightPosition = lightpath.Evaluate(lightT);

                RedrawOverlays();

                return;

            }


            if (!isDragging) return;
            var pos = e.GetPosition(DrawingCanvas);
            var dx = (float)(pos.X - lastMousePosition.X);
            var dy = (float)(pos.Y - lastMousePosition.Y);
            rotationController.Rotate(dx, dy);
            lastMousePosition = pos;
            UpdateRotatedMeshes();
            RedrawOverlays();
            RenderScene();
        }

        private void DrawingCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            bool wasDraggingLight = selectedLightPoint >= 0;

            selectedLightPoint = -1;
            isDragging= false;
            if (DrawingCanvas.IsMouseCaptured)
            {
                DrawingCanvas.ReleaseMouseCapture();
            }
            if (wasDraggingLight) {
                lightingSettings.LightPosition = lightpath.Evaluate(lightT);

                RenderScene();
            }
        }

        private void DrawingCanvas_LostMouseCapture(object sender, MouseEventArgs e)
        {
            isDragging = false;
            selectedLightPoint = -1;
        }

        private void LightingSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if(lightingSettings is null)
            {
                return;
            }
            lightingSettings.Kd=(float)KdSlider.Value;
            lightingSettings.Ks=(float)KsSlider.Value;
            lightingSettings.M=(float)MSlider.Value;
            RenderScene();
        }

        private void LightColorComboBox_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (lightingSettings is null)
                return;

            switch (LightColorComboBox.SelectedIndex)
            {
                case 0:
                    lightingSettings.LightColor = new Vector3(1, 1, 1);
                    break;

                case 1:
                    lightingSettings.LightColor = new Vector3(1, 0, 0);
                    break;

                case 2:
                    lightingSettings.LightColor = new Vector3(0, 1, 0);
                    break;

                case 3:
                    lightingSettings.LightColor = new Vector3(0, 0, 1);
                    break;
            }

            RenderScene();
        }

        private void SurfaceComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int index = SurfaceComboBox.SelectedIndex;
            if (Materials is null ||index < 0 ||index >= Materials.Count)
            {
                return;
            }
            SurfaceMaterial mat = Materials[index];
            updatingMaterialUI = true;
            SolidColorRadio.IsEnabled = true;
            SolidColorRadio.IsChecked = !mat.UseTexture;
            TextureRadio.IsChecked= mat.UseTexture;
            TextureRadio.IsEnabled = true;
            if (mat.SolidColor == new Vector3(1, 1, 1))
            {
                ObjectColorComboBox.SelectedIndex = 0;
            }
            if (mat.SolidColor == new Vector3(1, 0, 0))
            {
                ObjectColorComboBox.SelectedIndex = 1;
            }
            if (mat.SolidColor == new Vector3(0, 1, 0))
            {
                ObjectColorComboBox.SelectedIndex = 2;
            }
            if (mat.SolidColor == new Vector3(0, 0, 1))
            {
                ObjectColorComboBox.SelectedIndex = 3;
            }
            updatingMaterialUI = false;
            RenderScene();

        }

        private void MaterialMode_Changed(object sender, RoutedEventArgs e)
        {
            if (updatingMaterialUI||rasterizer is null)
            {
                return;
            }
            Materials[SurfaceComboBox.SelectedIndex].UseTexture = TextureRadio.IsChecked==true;
            RenderScene();
        }

        private void ObjectColorComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (updatingMaterialUI||rasterizer is null) return;

            var index = SurfaceComboBox.SelectedIndex;
            var mat = Materials[index];
            Vector3 color;
            switch (ObjectColorComboBox.SelectedIndex)
            {
                case 0:
                    color = new Vector3(1, 1, 1);
                    break;
                case 1: color = new Vector3(1, 0, 0);
                    break;
                    case 2: color = new Vector3(0, 1, 0);
                    break;
                    case 3: color = new Vector3(0, 0, 1);
                    break;
                default:
                    color = new Vector3(1, 1, 1);
                    break;
            }
            mat.SolidColor = color;
            RenderScene();
        }

        private void NormalMapCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            useNormalMap = NormalMapCheckBox.IsChecked == true;
            if (rasterizer is null)
            {
                return;
            }
            rasterizer.UseNormalMap = useNormalMap;
            RenderScene();
        }
        private void LightTimer_Tick(object? sender, EventArgs e)
        {
            float elapsed = (float)lightStopwatch.Elapsed.TotalSeconds;

            lightStopwatch.Restart();

            float delta = lightSpeed * elapsed;

            lightT = (lightT + delta)%1f;
            var lightpos = lightpath.Evaluate(lightT);
            lightingSettings.LightPosition = lightpos;
            RenderScene();
        }

        private void StartLightButton_Click(object sender, RoutedEventArgs e)
        {
            if (!lightTimer.IsEnabled)
            {
                lightStopwatch.Restart();
                lightTimer.Start();
            }
        }

        private void StopLightButton_Click(object sender, RoutedEventArgs e)
        {
            lightTimer.Stop();
            lightStopwatch.Stop();
        }

        private void LightSpeedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lightSpeed = (float)e.NewValue;
        }

        private void DisplayMode_Changed(object sender, RoutedEventArgs e)
        {
            if (rasterizer is null || meshes is null) return;

            RenderScene();
        }

        private void LightHeightSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (lightpath is null || lightingSettings is null)
                return;
            lightpath.SetHeight((float)e.NewValue);
            lightingSettings.LightPosition = lightpath.Evaluate(lightT);
            RenderScene();
        }
        private void DocumentationButton_Click(object sender, RoutedEventArgs e)
        {
            DocumentationWindow window = new DocumentationWindow();

            window.Owner = this;
            window.ShowDialog();
        }
    }
}