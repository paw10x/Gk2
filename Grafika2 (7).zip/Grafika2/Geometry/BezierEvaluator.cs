﻿using Grafika2.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Grafika2
{
    public static class BezierEvaluator
    {
        static float BernStein(int i, float t)
        {
            return i switch {
                0 => (1-t)*(1-t)*(1-t),
                1 => 3*t*(1-t)*(1-t),
                2 => 3*t*t*(1-t),
                3 => t*t*t,
                _ => throw new ArgumentOutOfRangeException("i musi być liczbą całkowitą od 0 do 3.")
            };
        }
        static float BernsteinDerivative(int i, float t)
        {
            return i switch
            {
                0 => -3 * (1 - t) * (1 - t),
                1 => 3*(1-t)*(1-3*t),
                2 => 3*t*(2-3*t),
                3 => 3*t*t,
                _ => throw new ArgumentOutOfRangeException("dupa1234")
            };
        }
        public static Vector3 Evaluate(BezierSurface sur, float u, float v)
        {
            float u1 = Math.Clamp(u, 0f, 1f);
            float v1 = Math.Clamp(v, 0f, 1f);
            Vector3 result = Vector3.Zero;
            for(int i = 0; i < 4; i++)
            {
                for(int j = 0;j<4;j++)
                {
                    Vector3 point = sur.ControlPoints[i,j];
                    float x = BernStein(i, u1) * BernStein(j, v1);
                    result += point * x;

                }
            }
            return result;
        }
        public static Vector3 EvaluatePu(BezierSurface sur, float u, float v)
        {
            float u1 = Math.Clamp(u, 0f, 1f);
            float v1 = Math.Clamp(v, 0f, 1f);
            Vector3 result = Vector3.Zero;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Vector3 point = sur.ControlPoints[i, j];
                    float x = BernsteinDerivative(i, u1) * BernStein(j, v1);
                    result += point * x;

                }
            }
            return result;
        }
        public static Vector3 EvaluatePv(BezierSurface sur, float u, float v)
        {
            float u1 = Math.Clamp(u, 0f, 1f);
            float v1 = Math.Clamp(v, 0f, 1f);
            Vector3 result = Vector3.Zero;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Vector3 point = sur.ControlPoints[i, j];
                    float x = BernStein(i, u1) * BernsteinDerivative(j, v1);
                    result += point * x;

                }
            }
            return result;
        }
        public static Vector3 EvaluateNormal(BezierSurface sur, float u, float v)
        {
            Vector3 du = EvaluatePu(sur, u, v);
            Vector3 dv = EvaluatePv(sur, u, v);
            Vector3 result = Vector3.Cross(du,dv);
            
            result = Vector3.Normalize(result);
            return result;
        }
    }
}
